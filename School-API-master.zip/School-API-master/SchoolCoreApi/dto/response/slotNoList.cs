using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class SlotNoList
    {
        public int slotNo { get; set; }
        public string timeSlotFromTime { get; set; }
        public string timeSlotToTime { get; set; }
    }
}
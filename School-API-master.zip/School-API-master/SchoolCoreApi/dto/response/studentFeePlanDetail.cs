using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class StudentFeePlanDetails 
    {
        // public string json { get; set; }
        public int studentID { get; set; }
        public int feesPlanID { get; set; }

    }
}
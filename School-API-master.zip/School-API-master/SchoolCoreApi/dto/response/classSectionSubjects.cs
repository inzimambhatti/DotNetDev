namespace SchoolCoreApi.Entities
{
    public class ClassSectionSubjects
    {
        public int subjectID { get; set; }
        public string subjectTitle { get; set; }
        public int? A { get; set; }
        public int? B { get; set; }
        public int? C { get; set; }
        public int? D { get; set; }
        public int? E { get; set; }
        public int? F { get; set; }
        public int? G { get; set; }
    }
}
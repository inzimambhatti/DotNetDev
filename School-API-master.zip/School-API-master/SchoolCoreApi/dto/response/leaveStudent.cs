using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class LeaveStudent
    {
        public int todayOnLeaveStudents { get; set; }
        public int classCount { get; set; }
    }
}
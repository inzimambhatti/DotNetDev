using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class RemainingFeeCollection
    {
        public int remainingStudent { get; set; }     
        public int remianingAmount { get; set; }
    }
}
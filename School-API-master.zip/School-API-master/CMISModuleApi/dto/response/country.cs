using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMISModuleApi.Entities
{
    public class Country
    {
        public int countory_id { get; set; }
        public string country_name { get; set; }
        public string country_code { get; set; }
    }
}
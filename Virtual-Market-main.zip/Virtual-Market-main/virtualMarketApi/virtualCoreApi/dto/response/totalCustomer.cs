using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace virtualCoreApi.Entities
{
    public class TotalCustomer
    {
        public int customers { get; set; }
    }
}
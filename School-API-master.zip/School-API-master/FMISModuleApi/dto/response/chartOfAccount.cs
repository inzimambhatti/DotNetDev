using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FMISModuleApi.Entities
{
    public class ChartOfAccount
    {
        public int levelo1 { get; set; }
        public string coaTitle { get; set; }
        public string coaCode { get; set; }
    }
}
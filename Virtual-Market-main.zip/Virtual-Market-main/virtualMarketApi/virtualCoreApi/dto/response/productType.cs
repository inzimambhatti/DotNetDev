using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace virtualCoreApi.Entities
{
    public class ProductType
    {
        public int productTypeID { get; set; }
        public string productTypeTitle { get; set; }
    }
}
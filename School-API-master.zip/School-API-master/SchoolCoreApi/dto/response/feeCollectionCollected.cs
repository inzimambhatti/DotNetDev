using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class FeeCollectionCollected
    {
        public int collectedStudent { get; set; }     
        public int collectedAmount { get; set; }     
    }
}
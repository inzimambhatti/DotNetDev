using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace virtualCoreApi.Entities
{
    public class CancelOrder
    {
        public int cancelOrders { get; set; }
        public float balance { get; set; }
    }
}
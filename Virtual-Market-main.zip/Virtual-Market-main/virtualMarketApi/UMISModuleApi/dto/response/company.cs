namespace UMISModuleAPI.Entities
{
    public class Company
    {
        public string companyShortName { get; set; }
        public string registerationDoc { get; set; }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class TotalStudents
    {
        public int totalNoOfStudents { get; set; }
        public int classCount { get; set; }
        // public int todayAbsentStudents { get; set; }
        // public int todayOnLeaveStudents { get; set; }
        
    }
}
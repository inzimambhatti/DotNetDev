namespace UMISModuleApi.dto.response
{
    public class UserDesignation
    {
        public int userID { get; set; }
        public int designationID { get; set; }
        public string empName { get; set; }
        public string loginName { get; set; }
        public string designationName { get; set; }
    }
}
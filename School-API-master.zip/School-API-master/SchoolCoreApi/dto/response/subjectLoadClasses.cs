using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class SubjectLoadClasses
    {
        public int classID { get; set; }
        public int sectionID { get; set; }
        public string className { get; set; }
    }
}
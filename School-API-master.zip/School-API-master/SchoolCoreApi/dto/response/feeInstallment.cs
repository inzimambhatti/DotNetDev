using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class FeeInstallment
    {
        public int feeInstallmentFeeID { get; set; }
        public string feeInstallmentMonth { get; set; }
        public string feeInstallmentName { get; set; }
        
    }
}
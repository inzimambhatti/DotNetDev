namespace UMISModuleAPI.Entities
{
    public class EventRoles
    {
        public int roleID { get; set; }
        public string roleTitle { get; set; }
        public bool status { get; set; }
    }
}
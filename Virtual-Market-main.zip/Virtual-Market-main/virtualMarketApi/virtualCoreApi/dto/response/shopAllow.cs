using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace virtualCoreApi.Entities
{
    public class shopAllow
    {
        public int shopCount { get; set; }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class ElementRulesDetails
    {
        public int feesElementID { get; set; }
        public string feesElementTitle { get; set; } 
        public int feesELementRulelID { get; set; }
        public string feeselementRuleType { get; set; }
        public int feesElementTypeID { get; set; } 
        public string feesElementTypeTitle { get; set; }
    }
}
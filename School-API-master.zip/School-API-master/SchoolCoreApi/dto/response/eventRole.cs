namespace SchoolCoreApi.Entities
{
    public class EventRole
    {
        public int eventID { get; set; }
        public string roleTitle { get; set; }
    }
}
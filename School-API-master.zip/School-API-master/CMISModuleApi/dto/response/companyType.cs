using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMISModuleApi.Entities
{
    public class companyType
    {
        public int company_type_id { get; set; }
        public string company_type_title { get; set; }
        public string company_type_description { get; set; }
    }
}
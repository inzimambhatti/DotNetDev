using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class FeeElementType
    {
        public int feesElementTypeID { get; set; }
        public string feesElementTypeTitle { get; set; } 
    }
}
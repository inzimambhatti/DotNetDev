namespace virtualCoreApi.Entities
{
    public class conStr
    {
        public string dbCon { get; set; }
    }
}
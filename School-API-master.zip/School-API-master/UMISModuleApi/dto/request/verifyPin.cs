using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UMISModuleAPI.Entities
{
    public class verifyPin
    {
        public int userPincode { get; set; }
        
        public int userID { get; set; }
        
        public string SpType { get; set; }

    }
}
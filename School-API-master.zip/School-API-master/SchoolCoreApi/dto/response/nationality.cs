using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class Nationality
    {
        public int nationalityID { get; set; }
        public string nationalityName { get; set; }
    }
}
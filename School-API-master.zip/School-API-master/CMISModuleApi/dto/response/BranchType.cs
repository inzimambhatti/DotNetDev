using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMISModuleApi.Entities
{
    public class BranchType
    {
        public int branch_type_id { get; set; }
        public string branch_type_title { get; set; }
    }
}
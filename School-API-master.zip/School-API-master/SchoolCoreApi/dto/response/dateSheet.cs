using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class DateSheet
    {
        public string markableEventDetailFromDate { get; set; }
        public string dName { get; set; }
        public string json { get; set; }
    }
}
namespace FMISApi.Configuration
{
    public class conStr
    {
        public string dbCon { get; set; }
    }
}
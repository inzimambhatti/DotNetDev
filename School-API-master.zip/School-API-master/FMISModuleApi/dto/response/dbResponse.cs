namespace FMISModuleApi.Configuration
{
    public class DBResponse
    {
        public string response { get; set; }
    }
}
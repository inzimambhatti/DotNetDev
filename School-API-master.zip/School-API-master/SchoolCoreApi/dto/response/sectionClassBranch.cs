using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class SectionClassBranch
    {
        public string sectionName { get; set; }
        public string className { get; set; }
        public string branch_name { get; set; }
    }
}
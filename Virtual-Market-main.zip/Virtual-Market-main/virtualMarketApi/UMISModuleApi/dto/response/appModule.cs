namespace UMISModuleAPI.Entities
{
    public class AppModule
    {
        public int applicationModuleId { get; set; }
        public string applicationModuleTitle { get; set; }
        public string applicationModuleDescription { get; set; }
    }
}
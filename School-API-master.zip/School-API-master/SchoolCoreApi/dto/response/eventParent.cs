using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class EventParent
    {
        public int eventParentID { get; set; }
        public string parentTitle { get; set; }
        public int Level { get; set; }
    }
}

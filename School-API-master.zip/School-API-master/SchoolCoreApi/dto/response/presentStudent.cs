using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class PresentStudent
    {
        public int todayPresentStudents { get; set; }
        public int classCount { get; set; }
    }
}
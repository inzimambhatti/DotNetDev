using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace virtualCoreApi.Entities
{
    public class Cities
    {
        public int cityID { get; set; }
        public string cityName { get; set; }
        public int countryID { get; set; }
    }
}
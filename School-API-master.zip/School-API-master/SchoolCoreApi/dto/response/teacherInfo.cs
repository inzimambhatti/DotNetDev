using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class TeacherInfo
    {
        public int teacherID { get; set; }
        public string teacherName { get; set; }
    }
}
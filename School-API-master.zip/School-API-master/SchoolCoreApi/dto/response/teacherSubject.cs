namespace SchoolCoreApi.Entities
{
    public class TeacherSubject
    {
        public int teacherID { get; set; }
        public int subjectID { get; set; }
        public string subjectTitle { get; set; }    
    }
}
namespace SchoolCoreApi.Entities
{
    public class CompletedEvents
    {
        public int completeEvents { get; set; }
    }
}
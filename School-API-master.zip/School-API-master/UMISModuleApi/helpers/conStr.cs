namespace UMISModuleAPI.Configuration
{
    public class conStr
    {
        public string dbCon { get; set; }
    }
}
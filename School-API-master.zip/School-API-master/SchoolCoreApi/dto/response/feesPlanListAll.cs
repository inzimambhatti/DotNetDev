using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class FeesPlanListAll
    {
        public int feesPlanID { get; set; }
        public string feesPlanTitle { get; set; }

    }
}
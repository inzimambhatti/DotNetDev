using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class ParentType
    {
        public int parentTypeID { get; set; }
        public string parentTypeName { get; set; }
    }
}
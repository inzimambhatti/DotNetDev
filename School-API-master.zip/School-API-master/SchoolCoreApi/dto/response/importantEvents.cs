namespace SchoolCoreApi.Entities
{
    public class ImportantEvents
    {
        public int importantEvent { get; set; }
    }
}
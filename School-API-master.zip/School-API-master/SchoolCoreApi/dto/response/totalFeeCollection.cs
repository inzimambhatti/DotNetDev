using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolCoreApi.Entities
{
    public class TotalFeeCollection
    {
        public int totalStudent { get; set; }     
        public int totalAmount { get; set; }   

    }
}
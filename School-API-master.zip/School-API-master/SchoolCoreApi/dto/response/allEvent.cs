namespace SchoolCoreApi.Entities
{
    public class AllEvent
    {
        public int sessionEventID { get; set; }
    }
}
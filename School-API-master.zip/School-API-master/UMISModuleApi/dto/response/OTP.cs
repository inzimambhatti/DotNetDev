using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UMISModuleApi.Entities
{
    public class OTP
    {
        public int otpID { get; set; }
        public string otpNo { get; set; }
    }
}